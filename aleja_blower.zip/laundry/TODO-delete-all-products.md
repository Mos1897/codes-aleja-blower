# Delete All Products Feature

## Status: In Progress

### Step 1: [PENDING] Update html/inventory.html - Add button & modal
### Step 2: [PENDING] Update scripts/inventory.js - Add JS function
### Step 3: [PENDING] Test & Complete
