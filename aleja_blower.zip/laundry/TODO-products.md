# Products Functionality - TODO Steps

**Status: In Progress**

## Plan Steps:

### 1. ✅ Database Schema
- [x] Create database/laundry_products_schema.sql (products + inventory tables)
- [x] Execute schema in laundry DB

### 2. Backend Fixes
- [ ] Update api/config.php to use laundry DB
- [ ] Verify api/api.php product endpoints work

### 3. ✅ Frontend Updates
- [x] products.html/js: Remove image upload, add stock_quantity field
- [x] dashboard.js: Low stock alerts (<10), total products/inventory

### 4. Test
- [ ] Add product via products.html
- [ ] Verify dashboard totals update
- [ ] Low stock alert for stock_quantity <= 10

**Next: Create laundry_products_schema.sql**

