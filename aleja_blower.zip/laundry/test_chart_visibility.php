<!DOCTYPE html>
<html>
<head>
    <title>Chart Visibility Test</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        .chart-container { width: 300px; height: 300px; margin: 20px; border: 1px solid #ccc; }
        .test-section { margin: 20px 0; padding: 15px; border: 1px solid #ddd; }
    </style>
</head>
<body>
    <h1>Chart Visibility Test</h1>
    
    <div class="test-section">
        <h2>Payment Methods Chart Test</h2>
        <div class="chart-container">
            <canvas id="paymentMethodsChart"></canvas>
        </div>
        <button onclick="testChart()">Test Chart Update</button>
        <button onclick="testAPI()">Test API Call</button>
        <div id="results"></div>
    </div>

    <script>
        // Initialize chart
        const ctx = document.getElementById('paymentMethodsChart').getContext('2d');
        const paymentMethodsChart = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['Cash', 'Gcash', 'Bank Transfer'],
                datasets: [{
                    data: [0, 0, 0],
                    backgroundColor: [
                        'rgb(34, 197, 94)',
                        'rgb(59, 130, 246)',
                        'rgb(251, 146, 60)'
                    ]
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                }
            }
        });

        function testChart() {
            // Test with sample data
            paymentMethodsChart.data.datasets[0].data = [362837, 15500, 29000];
            paymentMethodsChart.update();
            document.getElementById('results').innerHTML = '<div style="color: green;">Chart updated with test data</div>';
        }

        async function testAPI() {
            try {
                const response = await fetch('../api/api.php?action=sales_by_payment_method');
                const data = await response.json();
                
                const allowedMethods = ['Cash', 'Gcash', 'Bank Transfer'];
                const realData = {};
                
                // Map real API data to allowed methods
                if (data && data.labels) {
                    data.labels.forEach((label, index) => {
                        if (allowedMethods.includes(label)) {
                            realData[label] = data.data[index];
                        }
                    });
                }
                
                paymentMethodsChart.data.datasets[0].data = allowedMethods.map(m => realData[m] || 0);
                paymentMethodsChart.update();
                
                document.getElementById('results').innerHTML = '<div style="color: green;">Chart updated with real API data: ' + JSON.stringify(realData) + '</div>';
                
            } catch (error) {
                document.getElementById('results').innerHTML = '<div style="color: red;">API Error: ' + error.message + '</div>';
            }
        }
    </script>
</body>
</html>
