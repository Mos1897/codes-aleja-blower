<?php
echo file_get_contents('https://aleja-blower.infinityfreeapp.com/api/api.php?action=sales_history');
?>