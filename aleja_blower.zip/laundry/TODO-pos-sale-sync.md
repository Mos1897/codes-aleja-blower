## POS Sale not showing in Dashboard - Analysis & Fix Plan

### Information Gathered:
1. **POS Flow** (scripts/pos.js):
   ```
   processSale() → POST api/api.php {action: 'process_sale', cart, payment_method}
   localStorage.setItem('salesDataUpdated', Date.now()) // notifies dashboard
   ```

2. **Backend** (api/config.php):
   ```
   processSale(): 
   - TXN ID: TXN + date + rand()
   - INSERT sales (transaction_id UNIQUE, total_amount, payment_method)
   - INSERT sales_items (sale_id, product_id, quantity...)
   - UPDATE products stock_quantity -= quantity
   ```

3. **Dashboard** (scripts/dashboard.js):
   ```
   loadDashboardData() → api.php?action=stats → getTodaySales(): COUNT/SUM sales DATE(created_at)=today
   loadRecentTransactions() → api.php?action=sales_history → getSalesHistory() JOIN sales_items, LEFT JOIN products
   No storage listener for 'salesDataUpdated'
   ```

### Root Cause:
- **No listener**: dashboard.js lacks `window.addEventListener('storage', ...)` for `'salesDataUpdated'`
- **No auto-refresh**: dashboard stats/transactions only load on page load

### Plan:
**Primary Fix**: Add storage listener + periodic refresh to dashboard.js like low-stock sync.

**Dependent Files:**
1. `scripts/dashboard.js` (add listener for salesDataUpdated → reloadDashboardData)

**Followup:**
- Test POS sale → navigate dashboard → verify recent transactions + today's sales update
- Command: Ensure XAMPP Apache/MySQL running

<ask_followup_question>Confirm plan to add sales sync to dashboard.js?</ask_followup_question>

