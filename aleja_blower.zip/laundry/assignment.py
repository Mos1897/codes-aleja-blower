print("Under the moonlight, I keep on dreaming")
print("Tomorrow’s sunrise feels so close to me")
