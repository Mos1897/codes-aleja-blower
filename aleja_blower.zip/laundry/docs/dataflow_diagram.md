# Laundry Management System - Data Flow Diagram

## Overview
This Mermaid diagram represents the high-level data flows in the Aleja Blower/Laundry web application. It shows interactions between users, frontend, backend APIs, database, and external services.

## Mermaid Data Flow Diagram
```mermaid
flowchart TD
    %% External Entities
    User[👤 User/Browser]
    Email[📧 Email Service PHPMailer]
    
    %% Processes
    AuthHTML[📄 Auth Pages<br/>index.html, otp.html]
    Frontend[🌐 Frontend JS<br/>dashboard.js, pos.js, etc.]
    APILogin[🔐 api/login.php<br/>api/register.php]
    APIMain[⚙️ api/api.php<br/>Main API Handler]
    DB[🗄️ MySQL 'laundry' DB]
    
    %% Data Stores (detailed)
    DBusers[(👥 users<br/>roles)]
    DBotp[(🔢 otp_verification)]
    DBprod[(📦 products<br/>categories<br/>inventory)]
    DBsales[(💰 sales<br/>sales_items)]
    
    %% Main Flows
    User -->|1. Login form| AuthHTML
    AuthHTML -->|2. fetch POST| APILogin
    APILogin -->|3. Verify credentials| DBusers
    APILogin -->|4. Generate OTP| DBotp
    APILogin -->|5. Send email| Email
    Email -->|6. OTP to user| User
    User -->|7. OTP verify| AuthHTML
    AuthHTML -->|8. Session| Frontend
    
    %% Dashboard Flow
    Frontend -->|9. GET stats/products| APIMain
    APIMain -->|10. Queries| DBprod
    APIMain -->|11. Counts/sales| DBsales
    APIMain -->|12. JSON stats| Frontend
    
    %% POS/Sales Flow
    Frontend -->|13. GET products| APIMain
    APIMain -->|14. SELECT products| DBprod
    Frontend -->|15. POST process_sale| APIMain
    APIMain -->|16. INSERT| DBsales
    APIMain -->|17. UPDATE stock| DBprod
    APIMain -->|18. JSON receipt| Frontend
    
    %% CRUD Flows
    Frontend -->|19. POST add/update/delete| APIMain
    APIMain <-->|20. INSERT/UPDATE/DELETE| DBprod
    
    %% Styling
    classDef userFill fill:#e3f2fd,stroke:#2196f3,stroke-width:2px
    classDef processFill fill:#f3e5f5,stroke:#9c27b0,stroke-width:2px
    classDef dbFill fill:#e8f5e8,stroke:#4caf50,stroke-width:2px,color:#000
    classDef emailFill fill:#fff3e0,stroke:#ff9800,stroke-width:2px
    
    class User,Email userFill,processFill
    class AuthHTML,Frontend,APILogin,APIMain processFill
    class DBusers,DBotp,DBprod,DBsales dbFill
```

## Key Data Flows Explained

### 1. **Authentication Flow** (Multi-step)
```
User → Auth HTML → api/login.php → DB(users) → DB(otp_verification) → Email → User → OTP Verify → Session
```
- Password verification with `password_verify()`
- OTP expires in 10 minutes
- Email via PHPMailer

### 2. **Dashboard/Reports Flow** (Read-heavy)
```
Frontend → api/api.php?action=stats → DB(products,inventory,sales) → JSON stats
```
- Real-time low stock alerts (stock_quantity ≤ 10)
- Sales trends, top items, payment methods

### 3. **POS Sale Flow** (Transactional)
```
Frontend Cart → POST process_sale → api/api.php → INSERT(sales,sales_items) → UPDATE(products.stock) → Receipt
```
- Atomic: inventory decreases, sales recorded
- Payment methods: cash/card/transfer
- localStorage notifications to dashboard

### 4. **Product Management** (CRUD)
```
Frontend → api/api.php (add/update/delete) ↔ DB(products/categories/inventory)
```

## Data Stores Details
| Table | Purpose | Key Fields |
|-------|---------|------------|
| `users` | Authentication | id, email, password_hash, role_id, status |
| `otp_verification` | 2FA | email, otp, expires_at |
| `products` | Catalog | id, name, price, stock_quantity, category_id |
| `sales` | Transactions | id, total_amount, payment_method, created_at |
| `sales_items` | Line items | sale_id, product_id, quantity, unit_price |

## Technologies
- **Frontend**: HTML/CSS/JS + fetch API
- **Backend**: PHP + PDO MySQL
- **Auth**: OTP email verification
- **XAMPP**: Local dev server

**View Instructions**: 
- VSCode: Install 'Mermaid Preview' extension
- GitHub/Markdown: Auto-renders
- Browser: Copy diagram code to [mermaid.live](https://mermaid.live)

