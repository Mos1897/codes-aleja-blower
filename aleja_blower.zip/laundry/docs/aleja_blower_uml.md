# Aleja Blower POS System - UML Overview

This document describes the core UML structure for Aleja Blower, including the main actors, use cases, and data model relationships.

## Use Case Diagram

```mermaid
%%{init: {"theme":"base","themeVariables":{"actorBorder":"#2f4f4f","actorBackground":"#f0f8ff","primaryColor":"#2a9d8f","secondaryColor":"#264653"}}}%%
usecaseDiagram
actor Admin
actor Cashier
actor Guest

Admin --> (Manage Products)
Admin --> (Manage Inventory)
Admin --> (View Sales Dashboard)
Admin --> (Generate Reports)
Cashier --> (Process Sale)
Cashier --> (Add Item to Cart)
Cashier --> (Apply Payment)
Cashier --> (View Today’s Sales)
Guest --> (Browse Product Catalog)
Guest --> (Register / Login)
Guest --> (Request Password Reset)

(Manage Inventory) ..> (Update Stock) : <<include>>
(Manage Products) ..> (Add or Edit Product) : <<include>>
(Process Sale) ..> (Generate Receipt) : <<include>>
(Generate Reports) ..> (View Sales Dashboard) : <<include>>
```

## Class Diagram

```mermaid
classDiagram
    class User {
        +int id
        +string email
        +string passwordHash
        +string role
        +login()
        +resetPassword()
    }

    class Product {
        +int id
        +string sku
        +string name
        +float price
        +int quantity
        +updateStock()
    }

    class Cart {
        +int id
        +list items
        +addItem()
        +removeItem()
        +calculateTotal()
    }

    class Sale {
        +int id
        +DateTime date
        +float totalAmount
        +string paymentMethod
        +processSale()
        +createReceipt()
    }

    class Report {
        +DateTime startDate
        +DateTime endDate
        +generateSummary()
        +export()
    }

    User <|-- Admin
    User <|-- Cashier
    Cart --> Product
    Sale --> Cart
    Sale --> User
    Report --> Sale
    Report --> Product
```

