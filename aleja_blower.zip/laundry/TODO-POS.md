# POS "Failed to process sale" Fix - TODO

**Status: Plan Ready** 

## Step 1: Database Schema
- [ ] Execute `c:/xampp/mysql/bin/mysql.exe -u root laundry < database/products_schema.sql`

## Step 2: Fix api/config.php processSale()
- [ ] Implement real processSale() with sales/sales_items insert
- [ ] Update inventory stock_quantity

## Step 3: Test
- [ ] http://localhost/laundry/html/pos.html
- [ ] Add items → Complete Sale → Receipt ✓

**Next:** Run DB schema command above (XAMPP MySQL must run)

