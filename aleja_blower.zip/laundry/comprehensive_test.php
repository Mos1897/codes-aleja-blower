<!DOCTYPE html>
<html>
<head>
    <title>Comprehensive Chart Test</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        .test-section { margin: 20px 0; padding: 15px; border: 1px solid #ccc; }
        .result { padding: 10px; margin: 10px 0; }
        .pass { color: green; font-weight: bold; }
        .fail { color: red; font-weight: bold; }
        .data { background: #f5f5f5; padding: 10px; margin: 5px 0; }
        pre { background: #333; color: #fff; padding: 10px; overflow-x: auto; }
    </style>
</head>
<body>
    <h1>Comprehensive Chart Debugging</h1>
    
    <div class="test-section">
        <h2>Live API Tests</h2>
        <button onclick="runAllTests()">Run All Tests</button>
        <div id="testResults"></div>
    </div>

    <script>
        async function runAllTests() {
            const resultsDiv = document.getElementById('testResults');
            resultsDiv.innerHTML = '<div class="result">Running comprehensive tests...</div>';
            
            const tests = [
                {
                    name: 'Stats API',
                    url: '../api/api.php?action=stats',
                    expectedKeys: ['total_transactions', 'today_sales', 'total_products']
                },
                {
                    name: 'Payment Methods API',
                    url: '../api/api.php?action=sales_by_payment_method',
                    expectedKeys: ['labels', 'data', 'counts'],
                    expectedValues: ['Cash', 'GCash', 'Bank Transfer']
                },
                {
                    name: 'Top Selling Items API',
                    url: '../api/api.php?action=top_selling_items',
                    expectedKeys: ['product_name', 'total_quantity', 'total_revenue']
                }
            ];
            
            let results = '<h3>Test Results:</h3>';
            
            for (const test of tests) {
                try {
                    const response = await fetch(test.url);
                    const data = await response.json();
                    
                    let testResult = '<div class="result pass">';
                    let dataPreview = '';
                    
                    if (test.name === 'Stats API') {
                        const hasTransactions = data.total_transactions !== undefined;
                        const hasTodaySales = data.today_sales && data.today_sales.count !== undefined;
                        testResult += `✅ ${test.name}: Working<br>`;
                        testResult += `   - Total Transactions: ${hasTransactions ? data.total_transactions : 'MISSING'}<br>`;
                        testResult += `   - Today's Sales: ${hasTodaySales ? data.today_sales.count : 'MISSING'}<br>`;
                    }
                    else if (test.name === 'Payment Methods API') {
                        const hasCorrectLabels = test.expectedValues.every(val => data.labels.includes(val));
                        testResult += `✅ ${test.name}: Working<br>`;
                        testResult += `   - Labels: ${data.labels ? data.labels.join(', ') : 'MISSING'}<br>`;
                        testResult += `   - Expected Values: ${test.expectedValues.join(', ')}<br>`;
                        testResult += `   - Found Values: ${data.labels ? data.labels.join(', ') : 'NONE'}<br>`;
                    }
                    else if (test.name === 'Top Selling Items API') {
                        const hasItems = Array.isArray(data) && data.length > 0;
                        testResult += `✅ ${test.name}: Working<br>`;
                        testResult += `   - Items Count: ${hasItems ? data.length : '0'}<br>`;
                        if (hasItems && data[0]) {
                            testResult += `   - Top Item: ${data[0].product_name || 'UNKNOWN'}<br>`;
                        }
                    }
                    
                    testResult += '</div>';
                    
                    if (Object.keys(data).length > 0) {
                        dataPreview = '<div class="data"><pre>' + JSON.stringify(data, null, 2) + '</pre></div>';
                    }
                    
                    resultsDiv.innerHTML += testResult + dataPreview;
                    
                } catch (error) {
                    resultsDiv.innerHTML += `<div class="result fail">❌ ${test.name}: FAILED - ${error.message}</div>`;
                }
            }
            
            // Test browser cache clearing
            resultsDiv.innerHTML += '<button onclick="clearCacheAndReload()">Clear Cache & Reload</button>';
        }
        
        function clearCacheAndReload() {
            if (confirm('This will clear browser cache and reload the page. Continue?')) {
                // Clear cache if possible
                if ('caches' in window && caches.open) {
                    caches.keys().then(cacheNames => {
                        cacheNames.forEach(cacheName => {
                            caches.delete(cacheName);
                        });
                    });
                }
                
                // Reload page
                window.location.reload(true);
            }
        }
    </script>
</body>
</html>
