# POS Sale → Dashboard Sync Debug Plan

## Status: Debug Mode

### Step 1: [DONE] Analyze flows (pos.js, dashboard.js, config.php)

### Step 2: [PENDING] Test DB state
**Run test API to check sales table:**

`php api/test_api.php` → shows products/categories

`php api/test_sale.php` → test sale insertion + verify

### Step 3: [PENDING] Check API endpoints
Browser F12 → check Network tab:
1. POS sale POST api/api.php → success/error?
2. Dashboard GET stats → today's sales count/total?
3. Dashboard GET sales_history → records?

### Step 4: [PENDING] Fix getTodaySales/stats
**Issue:** config.php getTodaySales SELECT COUNT/SUM total_amount from sales DATE(created_at)=?

**If sales empty:** processSale failed (transaction_id UNIQUE conflict?)

### Step 5: [DONE] Add listener (already in dashboard.js)
```js
if (e.key === 'salesDataUpdated') loadDashboardData();
```

### Step 6: Complete
Test sale → navigate dashboard → verify stats/transactions

**Next:** User run `php api/test_sale.php` copy output

