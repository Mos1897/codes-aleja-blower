<?php
// Database configuration for Laundry app
// TODO: Update DB_NAME, DB_USER, DB_PASS to match your local database settings.

// InfinityFree database settings:
//   host: sql211.infinityfree.com
//   user: if0_41835849
//   password: Mark200418
//   database: if0_41835849_aleja

define('DB_HOST', 'sql211.infinityfree.com');
define('DB_NAME', 'if0_41835849_aleja');
define('DB_USER', 'if0_41835849');
define('DB_PASS', 'Mark200418');
