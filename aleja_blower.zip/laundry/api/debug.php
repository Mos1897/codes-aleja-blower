<?php
header('Content-Type: application/json');
// Minimal debug endpoint: returns PHP info and attempts a DB connection using api/config/database.php
$info = [];
$info['script'] = basename(__FILE__);
$info['time'] = date(DATE_ATOM);
$info['php_version'] = phpversion();
$info['php_ini'] = php_ini_loaded_file() ?: null;
$info['extensions'] = array_values(get_loaded_extensions());
$info['pdo_drivers'] = function_exists('PDO::getAvailableDrivers') ? PDO::getAvailableDrivers() : [];
$info['typed_properties_supported'] = version_compare(PHP_VERSION, '7.4.0', '>=');

// Database connectivity test (safe: does not echo credentials)
$dbResult = ['ok' => false, 'error' => null, 'tables_count' => 0, 'tables_sample' => []];
$dbConfigPath = __DIR__ . '/config/database.php';
if (file_exists($dbConfigPath)) {
    try {
        require_once $dbConfigPath; // defines DB_HOST, DB_NAME, DB_USER, DB_PASS
        if (defined('DB_HOST') && defined('DB_NAME') && defined('DB_USER') && defined('DB_PASS')) {
            try {
                $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
                $pdo = new PDO($dsn, DB_USER, DB_PASS, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]);
                $dbResult['ok'] = true;
                // list tables (limit to 50)
                $stmt = $pdo->query("SHOW TABLES");
                $tables = $stmt ? $stmt->fetchAll(PDO::FETCH_NUM) : [];
                $dbResult['tables_count'] = count($tables);
                $dbResult['tables_sample'] = array_slice(array_map(function($r) { return $r[0]; }, $tables), 0, 20);
            } catch (Exception $e) {
                $dbResult['error'] = $e->getMessage();
            }
        } else {
            $dbResult['error'] = 'DB constants not defined in config/database.php';
        }
    } catch (Throwable $t) {
        $dbResult['error'] = 'Error including database config: ' . $t->getMessage();
    }
} else {
    $dbResult['error'] = 'config/database.php not found';
}

$info['database'] = $dbResult;

echo json_encode($info, JSON_PRETTY_PRINT);
