<?php
// DB connectivity test using api/config/database.php
header('Content-Type: application/json');
ini_set('display_errors',1);
error_reporting(E_ALL);

$result = ['ok' => false, 'error' => null, 'tables' => []];
$dbConfigPath = __DIR__ . '/config/database.php';

if (!file_exists($dbConfigPath)) {
    $result['error'] = 'config/database.php not found';
    echo json_encode($result, JSON_PRETTY_PRINT);
    exit;
}

try {
    require_once $dbConfigPath; // expects DB_HOST, DB_NAME, DB_USER, DB_PASS
    if (!defined('DB_HOST') || !defined('DB_NAME') || !defined('DB_USER') || !defined('DB_PASS')) {
        $result['error'] = 'DB constants not defined in config/database.php';
        echo json_encode($result, JSON_PRETTY_PRINT);
        exit;
    }

    $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
    $pdo = new PDO($dsn, DB_USER, DB_PASS, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]);

    $stmt = $pdo->query("SHOW TABLES");
    $tables = $stmt ? $stmt->fetchAll(PDO::FETCH_NUM) : [];
    $result['ok'] = true;
    $result['tables'] = array_map(function($r){ return $r[0]; }, $tables);
} catch (Exception $e) {
    $result['error'] = $e->getMessage();
}

echo json_encode($result, JSON_PRETTY_PRINT);
