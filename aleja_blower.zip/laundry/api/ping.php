<?php
header('Content-Type: application/json');
// Minimal endpoint to verify API path and PHP execution
echo json_encode([
    'success' => true,
    'message' => 'pong',
    'time' => date(DATE_ATOM),
    'script' => basename(__FILE__)
]);
