<?php
header('Content-Type: application/json; charset=utf-8');

$out = [
    'ok' => false,
    'message' => '',
];

// Determine recipient from GET or POST
$to = null;
if (!empty($_REQUEST['to'])) {
    $to = filter_var($_REQUEST['to'], FILTER_VALIDATE_EMAIL) ? $_REQUEST['to'] : null;
}

// Default recipient if none provided (do not expose private addresses in public repos)
if (!$to) {
    $to = 'no-reply@example.com';
}

// Check email config and PHPMailer availability
$emailConfigPath = __DIR__ . '/config/email_config.php';
$phpmailerPath = __DIR__ . '/../phpmailer/PHPMailer.php';

if (!file_exists($emailConfigPath)) {
    $out['message'] = 'email_config.php not found';
    echo json_encode($out, JSON_PRETTY_PRINT);
    exit;
}

if (!file_exists($phpmailerPath)) {
    $out['message'] = 'PHPMailer files not found; upload phpMailer directory to project root/phpmailer';
    echo json_encode($out, JSON_PRETTY_PRINT);
    exit;
}

require_once $emailConfigPath;

try {
    $service = new EmailService();
    $otp = rand(100000, 999999);
    $sent = $service->sendResendOTP($to, $otp);

    if ($sent) {
        $out['ok'] = true;
        $out['message'] = 'Test email sent (if SMTP allows it).';
        $out['to'] = $to;
    } else {
        $out['message'] = 'Email service attempted send but reported failure. Check server logs.';
    }
} catch (Throwable $t) {
    $out['message'] = 'Exception while sending: ' . $t->getMessage();
}

echo json_encode($out, JSON_PRETTY_PRINT);

?>
