<?php
// Simple existence check for API path
header('Content-Type: text/plain');
echo "OK";
