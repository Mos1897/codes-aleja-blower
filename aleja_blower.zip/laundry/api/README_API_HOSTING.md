API deployment & debug checklist

1) Upload these files/folders to your host public root (public_html or htdocs):
   - api/
     - register.php
     - login.php
     - test_ok.php
     - db_test.php
     - debug_verbose.php
     - ping.php
     - config/
         - database.php
         - email_config.php

2) Verify endpoints in browser after upload:
   - https://<your-site>/api/test_ok.php  -> should print: OK
   - https://<your-site>/api/ping.php     -> should return JSON {"success":true,...}
   - https://<your-site>/api/debug_verbose.php -> returns PHP info + DB include test
   - https://<your-site>/api/db_test.php  -> returns JSON with DB tables or error

3) If you see InfinityFree 404 page for any of the above:
   - Ensure files are inside the host's public folder (public_html or htdocs). Files outside will return 404.
   - Check filename casing (Linux hosts are case-sensitive).
   - Temporarily rename or move `.htaccess` if it contains rewrite rules redirecting to an error page.

4) If `debug_verbose.php` returns an empty response, enable PHP errors at top of that file by adding:
   ini_set('display_errors', 1);
   ini_set('display_startup_errors', 1);
   error_reporting(E_ALL);

5) PHP version:
   - Ensure PHP is >= 7.4. In InfinityFree control panel select PHP 7.4+.
   - I removed typed property syntax in `api/config/email_config.php` to improve compatibility.

6) After the API endpoints respond correctly, test register/login from the site and capture the failing request in DevTools (Network tab) and paste the Request URL + Response body here if still failing.

7) If DB connection fails, open phpMyAdmin and confirm DB credentials and DB name (match them in `api/config/database.php`).

If you want, I can generate a ZIP of the `api/` folder with these test files so you can upload all at once. Request: "create api zip" and I'll prepare it.