<?php
header('Content-Type: application/json; charset=utf-8');
$out = [
    'ok' => false,
    'php_version' => phpversion(),
    'db' => null,
];

// Check DB connection if config exists
if (file_exists(__DIR__ . '/config/database.php')) {
    require_once __DIR__ . '/config/database.php';

    try {
        $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4';
        $pdo = new PDO($dsn, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]);

        // List a few tables to confirm connectivity
        $stmt = $pdo->query("SHOW TABLES");
        $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);

        $out['db'] = [
            'connected' => true,
            'table_count' => count($tables),
            'tables' => array_slice($tables, 0, 50),
        ];
    } catch (Exception $e) {
        $out['db'] = [
            'connected' => false,
            'error' => $e->getMessage(),
        ];
    }
} else {
    $out['db'] = [
        'connected' => false,
        'error' => 'database.php not found',
    ];
}

$out['ok'] = true;
echo json_encode($out, JSON_PRETTY_PRINT);

?>
