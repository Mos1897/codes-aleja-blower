<!DOCTYPE html>
<html>
<head>
    <title>Debug Charts</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        .debug-section { margin: 20px 0; padding: 15px; border: 1px solid #ccc; }
        .api-test { margin: 10px 0; }
        .result { padding: 5px; margin: 5px 0; }
        .pass { color: green; }
        .fail { color: red; }
    </style>
</head>
<body>
    <h1>Chart Debug Dashboard</h1>
    
    <div class="debug-section">
        <h2>API Tests</h2>
        <div class="api-test">
            <button onclick="testAPI('stats')">Test Stats API</button>
            <button onclick="testAPI('sales_trend')">Test Trend API</button>
            <button onclick="testAPI('sales_by_category')">Test Category API</button>
            <button onclick="testAPI('sales_by_payment_method')">Test Payment API</button>
            <button onclick="testAPI('top_selling_items')">Test Top Items API</button>
        </div>
        <div id="results"></div>
    </div>

    <script>
        async function testAPI(endpoint) {
            const resultsDiv = document.getElementById('results');
            resultsDiv.innerHTML = '<div class="result">Testing ' + endpoint + '...</div>';
            
            try {
                const response = await fetch('../api/api.php?action=' + endpoint);
                const data = await response.json();
                
                let resultClass = 'pass';
                let resultText = '✅ ' + endpoint + ' API working';
                
                if (endpoint === 'top_selling_items') {
                    if (Array.isArray(data) && data.length > 0) {
                        resultText += '<br>Items: ' + data.length;
                        resultText += '<br>Top item: ' + (data[0]?.product_name || 'N/A');
                    } else {
                        resultClass = 'fail';
                        resultText = '❌ No items returned';
                    }
                }
                
                resultsDiv.innerHTML = '<div class="result ' + resultClass + '">' + resultText + '</div>';
                console.log(endpoint + ' API Result:', data);
                
            } catch (error) {
                resultsDiv.innerHTML = '<div class="result fail">❌ ' + endpoint + ' API failed: ' + error.message + '</div>';
                console.error(endpoint + ' API Error:', error);
            }
        }
        
        // Auto-test all APIs on load
        window.onload = () => {
            ['stats', 'sales_trend', 'sales_by_category', 'sales_by_payment_method', 'top_selling_items'].forEach(testAPI);
        };
    </script>
</body>
</html>
