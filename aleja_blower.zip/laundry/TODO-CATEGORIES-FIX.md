# TODO: Fix Products Categories Display (N/A Issue) 

**Status:** In Progress

## Breakdown of Approved Plan:
1. ✅ [DONE] Create this TODO.md tracker
2. ✅ Read/analyzed api/config.php getAllProducts()\n3. ✅ Created categories.php, edited api/config.php for table/JOIN (fixed syntax), updated JS categoryName & loadCategories async
4. [PENDING] Update getAllProducts() to SELECT category_name via CASE or JOIN
5. [PENDING] Fix JS loadCategories() to fetch from API ?action=categories, use string id matching form/DB
6. [PENDING] Update displayProducts() lookup if needed
7. [PENDING] Fix any mismatched product data via SQL UPDATE
8. [PENDING] Test: Load products.html, verify categories show names
9. [PENDING] Update this TODO with completion, attempt_completion

**Next Step:** Implement DB categories table and API changes
